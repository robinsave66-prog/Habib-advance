package com.habib.wealth.data
import androidx.room.withTransaction
import kotlinx.coroutines.flow.*
class WealthRepository(private val db:WealthDatabase){
private val dao=db.dao()
val accounts=dao.observeAccounts()
val transactions=dao.observeTransactions()
val expenseNotes=dao.observeExpenseNotes()
val familyMembers=dao.observeFamilyMembers()
fun familyEntries(memberId:Long)=dao.observeFamilyEntries(memberId)
fun familySummary(member:FamilyMemberEntity,entries:List<FamilyEntryEntity>):FamilyMemberSummary {
val now=java.util.Calendar.getInstance(); val month=now.get(java.util.Calendar.MONTH); val year=now.get(java.util.Calendar.YEAR)
fun signed(e:FamilyEntryEntity)=if(e.type=="ADD")e.amountPoisha else -e.amountPoisha
val monthly=entries.filter{val c=java.util.Calendar.getInstance().apply{timeInMillis=it.entryDate};c.get(java.util.Calendar.MONTH)==month&&c.get(java.util.Calendar.YEAR)==year}.sumOf(::signed)
val yearly=entries.filter{java.util.Calendar.getInstance().apply{timeInMillis=it.entryDate}.get(java.util.Calendar.YEAR)==year}.sumOf(::signed)
return FamilyMemberSummary(member.id,member.name,member.relation,entries.sumOf(::signed),monthly,yearly)
}
suspend fun addFamilyMember(name:String,relation:String){require(name.isNotBlank()){"সদস্যের নাম লিখুন"};dao.insertFamilyMember(FamilyMemberEntity(name=name.trim(),relation=relation))}
suspend fun saveFamilyEntry(e:FamilyEntryEntity){require(e.amountPoisha>0){"পরিমাণ শূন্যের বেশি হতে হবে"};require(e.title.isNotBlank()){"বিবরণ লিখুন"};require(dao.familyEntryCount(e.memberId)>=0);if(e.id==0L)dao.insertFamilyEntry(e) else dao.updateFamilyEntry(e)}
suspend fun deleteFamilyEntry(e:FamilyEntryEntity)=dao.deleteFamilyEntry(e)
suspend fun deleteFamilyMember(m:FamilyMemberEntity){require(dao.familyEntryCount(m.id)==0){"এই সদস্যের হিসাব আছে; আগে হিসাব মুছুন"};dao.deleteFamilyMember(m)}
val balances=combine(accounts,transactions){ aa,tt -> aa.map{a->
var b=a.openingBalancePoisha
tt.forEach{t->when(t.type){"INCOME"->if(t.accountId==a.id)b+=t.amountPoisha;"EXPENSE"->if(t.accountId==a.id)b-=t.amountPoisha;"TRANSFER"->{if(t.accountId==a.id)b-=t.amountPoisha;if(t.destinationAccountId==a.id)b+=t.amountPoisha}}}
AccountBalance(a.id,a.name,a.type,b)
}}
suspend fun addAccount(n:String,t:String,opening:Long){require(n.isNotBlank()){"অ্যাকাউন্টের নাম লিখুন"};require(opening>=0);dao.insertAccount(AccountEntity(name=n.trim(),type=t,openingBalancePoisha=opening))}
suspend fun saveTransaction(t:TransactionEntity){
require(t.amountPoisha>0){"টাকার পরিমাণ শূন্যের বেশি হতে হবে"};require(dao.getAccount(t.accountId)!=null){"অ্যাকাউন্ট পাওয়া যায়নি"}
if(t.type=="TRANSFER"){require(t.destinationAccountId!=null&&t.destinationAccountId!=t.accountId){"ভিন্ন গন্তব্য অ্যাকাউন্ট নির্বাচন করুন"};require(dao.getAccount(t.destinationAccountId)!=null){"গন্তব্য অ্যাকাউন্ট পাওয়া যায়নি"}}
db.withTransaction{if(t.id==0L)dao.insertTransaction(t) else dao.updateTransaction(t)}
}
suspend fun deleteTransaction(t:TransactionEntity)=dao.deleteTransaction(t)
suspend fun saveExpenseNote(n:ExpenseNoteEntity){require(n.title.isNotBlank()){"নোটের শিরোনাম লিখুন"};require(n.amountPoisha>0){"টাকার পরিমাণ শূন্যের বেশি হতে হবে"};if(n.id==0L)dao.insertExpenseNote(n) else dao.updateExpenseNote(n)}
suspend fun deleteExpenseNote(n:ExpenseNoteEntity)=dao.deleteExpenseNote(n)
suspend fun deleteAccount(a:AccountEntity){require(dao.transactionCountForAccount(a.id)==0){"এই অ্যাকাউন্টে লেনদেন আছে"};dao.deleteAccount(a)}
}
