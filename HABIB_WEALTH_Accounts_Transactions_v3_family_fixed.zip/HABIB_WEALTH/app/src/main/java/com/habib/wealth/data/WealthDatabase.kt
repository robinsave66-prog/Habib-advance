package com.habib.wealth.data
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
@Database(entities=[AccountEntity::class,TransactionEntity::class,ExpenseNoteEntity::class,FamilyMemberEntity::class,FamilyEntryEntity::class],version=3,exportSchema=false)
abstract class WealthDatabase:RoomDatabase(){
abstract fun dao():WealthDao
companion object {
val MIGRATION_1_2=object:Migration(1,2){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS expense_notes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, amountPoisha INTEGER NOT NULL, note TEXT NOT NULL, noteDate INTEGER NOT NULL, createdAt INTEGER NOT NULL)")}}
val MIGRATION_2_3=object:Migration(2,3){override fun migrate(db:SupportSQLiteDatabase){
db.execSQL("CREATE TABLE IF NOT EXISTS family_members (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, relation TEXT NOT NULL, photoUri TEXT, createdAt INTEGER NOT NULL)")
db.execSQL("CREATE TABLE IF NOT EXISTS family_entries (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, memberId INTEGER NOT NULL, type TEXT NOT NULL, amountPoisha INTEGER NOT NULL, title TEXT NOT NULL, note TEXT NOT NULL, entryDate INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
db.execSQL("CREATE INDEX IF NOT EXISTS index_family_entries_memberId ON family_entries(memberId)")
db.execSQL("CREATE INDEX IF NOT EXISTS index_family_entries_entryDate ON family_entries(entryDate)")
}}
@Volatile private var INSTANCE:WealthDatabase?=null
fun get(c:Context):WealthDatabase=INSTANCE?: synchronized(this){INSTANCE?:Room.databaseBuilder(c.applicationContext,WealthDatabase::class.java,"habib_wealth.db").addMigrations(MIGRATION_1_2,MIGRATION_2_3).build().also{INSTANCE=it}}
}
}
