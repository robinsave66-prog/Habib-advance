package com.habib.wealth.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface WealthDao {
@Query("SELECT * FROM family_members ORDER BY name COLLATE NOCASE") fun observeFamilyMembers():Flow<List<FamilyMemberEntity>>
@Query("SELECT * FROM family_entries WHERE memberId=:memberId ORDER BY entryDate DESC,id DESC") fun observeFamilyEntries(memberId:Long):Flow<List<FamilyEntryEntity>>
@Insert suspend fun insertFamilyMember(m:FamilyMemberEntity):Long
@Update suspend fun updateFamilyMember(m:FamilyMemberEntity)
@Delete suspend fun deleteFamilyMember(m:FamilyMemberEntity)
@Query("SELECT COUNT(*) FROM family_entries WHERE memberId=:memberId") suspend fun familyEntryCount(memberId:Long):Int
@Insert suspend fun insertFamilyEntry(e:FamilyEntryEntity):Long
@Update suspend fun updateFamilyEntry(e:FamilyEntryEntity)
@Delete suspend fun deleteFamilyEntry(e:FamilyEntryEntity)

@Query("SELECT * FROM expense_notes ORDER BY noteDate DESC,id DESC") fun observeExpenseNotes():Flow<List<ExpenseNoteEntity>>
@Insert suspend fun insertExpenseNote(n:ExpenseNoteEntity):Long
@Update suspend fun updateExpenseNote(n:ExpenseNoteEntity)
@Delete suspend fun deleteExpenseNote(n:ExpenseNoteEntity)
@Query("SELECT * FROM accounts ORDER BY id") fun observeAccounts():Flow<List<AccountEntity>>
@Query("SELECT * FROM transactions ORDER BY transactionDate DESC,id DESC") fun observeTransactions():Flow<List<TransactionEntity>>
@Query("SELECT * FROM accounts WHERE id=:id") suspend fun getAccount(id:Long):AccountEntity?
@Query("SELECT COUNT(*) FROM transactions WHERE accountId=:id OR destinationAccountId=:id") suspend fun transactionCountForAccount(id:Long):Int
@Insert suspend fun insertAccount(a:AccountEntity):Long
@Delete suspend fun deleteAccount(a:AccountEntity)
@Insert suspend fun insertTransaction(t:TransactionEntity):Long
@Update suspend fun updateTransaction(t:TransactionEntity)
@Delete suspend fun deleteTransaction(t:TransactionEntity)
}
