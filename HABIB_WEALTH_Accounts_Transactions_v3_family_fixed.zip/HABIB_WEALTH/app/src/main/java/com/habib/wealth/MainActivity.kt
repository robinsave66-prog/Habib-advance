package com.habib.wealth
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.habib.wealth.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale
private val navy=Color(0xFF0B1424); private val panel=Color(0xFF152238); private val gold=Color(0xFFE3B85C); private val teal=Color(0xFF48C6B7); private val soft=Color(0xFFEAF0F7)
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{WealthApp(WealthRepository(WealthDatabase.get(this)))}}}
class WealthVM(private val repo:WealthRepository):ViewModel(){
val accounts=repo.accounts.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val txs=repo.transactions.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val notes=repo.expenseNotes.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val family=repo.familyMembers.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val balances=repo.balances.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
var message by mutableStateOf<String?>(null)
fun run(block:suspend()->Unit){viewModelScope.launch{try{block();message="সংরক্ষণ সম্পন্ন হয়েছে"}catch(e:Exception){message=e.message?:"সমস্যা হয়েছে"}}}
companion object{fun factory(r:WealthRepository)=viewModelFactory{initializer{WealthVM(r)}}}
}
@Composable fun WealthApp(repo:WealthRepository){
    val vm: WealthVM = viewModel(factory = WealthVM.factory(repo))
    val accounts by vm.accounts.collectAsState()
    val txs by vm.txs.collectAsState()
    val notes by vm.notes.collectAsState()
    val family by vm.family.collectAsState()
    var selectedFamily by remember { mutableStateOf<FamilyMemberEntity?>(null) }
    val familyEntriesFlow = remember(selectedFamily?.id) { selectedFamily?.let { repo.familyEntries(it.id) } }
    val familyEntries by (familyEntriesFlow ?: kotlinx.coroutines.flow.flowOf(emptyList())).collectAsState(initial = emptyList())
    val balances by vm.balances.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var accountDialog by remember { mutableStateOf(false) }
    var txDialog by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<TransactionEntity?>(null) }
    var noteDialog by remember { mutableStateOf(false) }
    var noteEdit by remember { mutableStateOf<ExpenseNoteEntity?>(null) }
    var familyAdd by remember { mutableStateOf(false) }
    var familyEntryDialog by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = gold, secondary = teal, background = navy, surface = panel, onBackground = soft, onSurface = soft)) {
        Scaffold(
            containerColor = navy,
            bottomBar = {
                NavigationBar(containerColor = panel) {
                    listOf("হোম", "অ্যাকাউন্ট", "লেনদেন", "খরচের নোট", "Family").forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(Icons.Default.Add, null) }, label = { Text(label) })
                    }
                }
            },
            floatingActionButton = {
                if (tab > 0) {
                    FloatingActionButton(onClick = { if (tab == 1) accountDialog = true else if (tab == 2) { edit = null; txDialog = true } else if(tab==3) { noteEdit = null; noteDialog = true } else if(tab==4 && selectedFamily!=null) familyEntryDialog=true else if(tab==4) familyAdd=true }, containerColor = gold) {
                        Icon(Icons.Default.Add, null)
                    }
                }
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
                Text("HABIB WEALTH", color = gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("আপনার অর্থ, আপনার নিয়ন্ত্রণে", color = soft.copy(alpha = .7f))
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("মোট অ্যাকাউন্ট ব্যালেন্স")
                                Text(money(balances.sumOf { it.balancePoisha }), color = gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("সাম্প্রতিক লেনদেন", color = soft)
                        TxList(txs, accounts, { edit = it; txDialog = true }, { vm.run { repo.deleteTransaction(it) } })
                    }
                    1 -> {
                        Text("আমার অ্যাকাউন্ট", color = soft, fontSize = 20.sp)
                        Text("＋ অ্যাকাউন্ট যোগ করুন", color = gold, modifier = Modifier.clickable { accountDialog = true })
                        if (balances.isEmpty()) Hint("এখনো অ্যাকাউন্ট নেই। Cash, Bank বা bKash যোগ করুন।")
                        LazyColumn {
                            items(balances, key = { it.id }) { b ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
                                    Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) { Text(b.name, color = soft, fontWeight = FontWeight.Bold); Text(b.type, color = teal) }
                                        Text(money(b.balancePoisha), color = gold)
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        Text("সব লেনদেন", color = soft, fontSize = 20.sp)
                        TxList(txs, accounts, { edit = it; txDialog = true }, { vm.run { repo.deleteTransaction(it) } })
                    }
                    3 -> {
                        Text("স্বতন্ত্র খরচের নোট", color = soft, fontSize = 20.sp)
                        Text("এই নোট মূল লেনদেন বা অ্যাকাউন্ট ব্যালেন্সে যোগ হবে না।", color = teal, fontSize = 12.sp)
                        ExpenseNoteList(notes, { noteEdit = it; noteDialog = true }, { vm.run { repo.deleteExpenseNote(it) } })
                    }
                    else -> {
                        if(selectedFamily==null){
                            Text("Family Ledger",color=soft,fontSize=20.sp)
                            Text("প্রতিটি সদস্যের আজীবন, মাসিক ও বার্ষিক হিসাব আলাদা থাকবে।",color=teal,fontSize=12.sp)
                            FamilyMemberList(family,{selectedFamily=it},{vm.run{repo.deleteFamilyMember(it)}})
                            TextButton(onClick={familyAdd=true}){Text("＋ পরিবারের সদস্য যোগ করুন",color=gold)}
                        } else {
                            val member=selectedFamily!!
                            TextButton(onClick={selectedFamily=null}){Text("← পরিবারের তালিকা",color=gold)}
                            Text(member.name,color=soft,fontSize=22.sp,fontWeight=FontWeight.Bold)
                            Text(member.relation,color=teal)
                            val summary=repo.familySummary(member,familyEntries)
                            FamilyTotals(summary)
                            FamilyEntryList(familyEntries,{vm.run{repo.deleteFamilyEntry(it)}})
                        }
                    }
                }
            }
        }
        if (accountDialog) AccountForm({ accountDialog = false }) { n, t, v -> vm.run { repo.addAccount(n, t, v) }; accountDialog = false }
        if (txDialog) TxForm(accounts, edit, { txDialog = false }) { t -> vm.run { repo.saveTransaction(t) }; txDialog = false }
        if (noteDialog) ExpenseNoteForm(noteEdit, { noteDialog = false }) { n -> vm.run { repo.saveExpenseNote(n) }; noteDialog = false }
        if(familyAdd) FamilyMemberForm({familyAdd=false}){n,r->vm.run{repo.addFamilyMember(n,r)};familyAdd=false}
        if(familyEntryDialog && selectedFamily!=null) FamilyEntryForm(selectedFamily!!,{familyEntryDialog=false}){e->vm.run{repo.saveFamilyEntry(e)};familyEntryDialog=false}
        vm.message?.let { message ->
            AlertDialog(onDismissRequest = { vm.message = null }, confirmButton = { TextButton(onClick = { vm.message = null }) { Text("ঠিক আছে") } }, title = { Text("HABIB WEALTH") }, text = { Text(message) }, containerColor = panel)
        }
    }
}
@Composable fun Hint(s:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=panel)){Text(s,Modifier.padding(16.dp),color=soft)}}
@Composable fun AccountForm(close:()->Unit,save:(String,String,Long)->Unit){
var n by remember{mutableStateOf("")};var type by remember{mutableStateOf("Cash")};var opening by remember{mutableStateOf("0")}
AlertDialog(onDismissRequest=close,title={Text("নতুন অ্যাকাউন্ট")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(n,{n=it},label={Text("অ্যাকাউন্টের নাম")});Row{listOf("Cash","Bank","bKash").forEach{FilterChip(type==it,{type=it},label={Text(it)})}};OutlinedTextField(opening,{opening=it},label={Text("প্রারম্ভিক ব্যালেন্স (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))}},confirmButton={TextButton(onClick={parsePoisha(opening)?.let{save(n,type,it)}}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}
@Composable fun TxForm(accounts:List<AccountEntity>,old:TransactionEntity?,close:()->Unit,save:(TransactionEntity)->Unit){
var type by remember{mutableStateOf(old?.type?:"EXPENSE")};var amount by remember{mutableStateOf(old?.let{decimal(it.amountPoisha)}?:"")};var aid by remember{mutableLongStateOf(old?.accountId?:accounts.firstOrNull()?.id?:0L)};var dest by remember{mutableLongStateOf(old?.destinationAccountId?:accounts.firstOrNull{it.id!=aid}?.id?:0L)};var title by remember{mutableStateOf(old?.title?:"")};var note by remember{mutableStateOf(old?.note?:"")}
AlertDialog(onDismissRequest=close,title={Text(if(old==null)"নতুন লেনদেন" else "লেনদেন সম্পাদনা")},text={Column(Modifier.heightIn(max=470.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
Row{listOf("INCOME" to "আয়","EXPENSE" to "খরচ","TRANSFER" to "ট্রান্সফার").forEach{(v,l)->FilterChip(type==v,{type=v},label={Text(l)})}}
OutlinedTextField(amount,{amount=it},label={Text("পরিমাণ (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
Text("অ্যাকাউন্ট");accounts.forEach{a->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(aid==a.id,{aid=a.id});Text(a.name)}}
if(type=="TRANSFER"){Text("গন্তব্য অ্যাকাউন্ট");accounts.filter{it.id!=aid}.forEach{a->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(dest==a.id,{dest=a.id});Text(a.name)}}}
OutlinedTextField(title,{title=it},label={Text("কারণ / শিরোনাম")});OutlinedTextField(note,{note=it},label={Text("বিস্তারিত (ঐচ্ছিক)")})
}},confirmButton={TextButton(onClick={val p=parsePoisha(amount);if(p!=null&&aid!=0L)save(TransactionEntity(id=old?.id?:0,type=type,amountPoisha=p,accountId=aid,destinationAccountId=if(type=="TRANSFER")dest else null,title=title.ifBlank{"লেনদেন"},note=note,transactionDate=old?.transactionDate?:System.currentTimeMillis(),createdAt=old?.createdAt?:System.currentTimeMillis()))}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}
@Composable fun TxList(txs:List<TransactionEntity>,accounts:List<AccountEntity>,edit:(TransactionEntity)->Unit,delete:(TransactionEntity)->Unit){
if(txs.isEmpty()){Hint("এখনো কোনো লেনদেন নেই। + চাপ দিয়ে প্রথম লেনদেন যোগ করুন।");return}
LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(txs,key={it.id}){t->val from=accounts.firstOrNull{it.id==t.accountId}?.name?:"";val to=accounts.firstOrNull{it.id==t.destinationAccountId}?.name?:"";Card(colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(12.dp).fillMaxWidth()){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.title,color=soft,fontWeight=FontWeight.Bold);Text(when(t.type){"INCOME"->"আয় • $from";"EXPENSE"->"খরচ • $from";else->"ট্রান্সফার • $from → $to"},color=teal,fontSize=12.sp)};Text((if(t.type=="INCOME")"+" else if(t.type=="EXPENSE")"−" else "")+money(t.amountPoisha),color=gold)};if(t.note.isNotBlank())Text(t.note,color=soft);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){TextButton(onClick={edit(t)}){Icon(Icons.Default.Edit,null);Text("এডিট")};TextButton(onClick={delete(t)}){Icon(Icons.Default.Delete,null);Text("মুছুন")}}}}}}
}
fun parsePoisha(s:String):Long?=try{val p=s.trim().replace(",","").split(".");if(p[0].isBlank())null else p[0].toLong()*100+(p.getOrNull(1)?:"").padEnd(2,'0').take(2).toLong()}catch(_:Exception){null}
fun money(p:Long)="৳"+String.format(Locale.US,"%,.2f",p/100.0)
fun decimal(p:Long)=String.format(Locale.US,"%.2f",p/100.0)

@Composable fun ExpenseNoteList(notes:List<ExpenseNoteEntity>,edit:(ExpenseNoteEntity)->Unit,delete:(ExpenseNoteEntity)->Unit){
if(notes.isEmpty()){Hint("এখনো কোনো খরচের নোট নেই। + চাপ দিয়ে আলাদা নোট যোগ করুন।");return}
LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(notes,key={it.id}){n->Card(colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(12.dp).fillMaxWidth()){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(n.title,color=soft,fontWeight=FontWeight.Bold);if(n.note.isNotBlank())Text(n.note,color=soft.copy(alpha=.75f))};Text(money(n.amountPoisha),color=gold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){TextButton(onClick={edit(n)}){Icon(Icons.Default.Edit,null);Text("এডিট")};TextButton(onClick={delete(n)}){Icon(Icons.Default.Delete,null);Text("মুছুন")}}}}}}
}
@Composable fun ExpenseNoteForm(old:ExpenseNoteEntity?,close:()->Unit,save:(ExpenseNoteEntity)->Unit){
var title by remember(old?.id){mutableStateOf(old?.title?:"")};var amount by remember(old?.id){mutableStateOf(old?.let{decimal(it.amountPoisha)}?:"")};var note by remember(old?.id){mutableStateOf(old?.note?:"")}
AlertDialog(onDismissRequest=close,title={Text(if(old==null)"নতুন খরচের নোট" else "নোট সম্পাদনা")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("শিরোনাম")});OutlinedTextField(amount,{amount=it},label={Text("পরিমাণ (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal));OutlinedTextField(note,{note=it},label={Text("বিস্তারিত (ঐচ্ছিক)")})}},confirmButton={TextButton(onClick={val p=parsePoisha(amount);if(p!=null&&title.isNotBlank())save(ExpenseNoteEntity(id=old?.id?:0,title=title.trim(),amountPoisha=p,note=note,noteDate=old?.noteDate?:System.currentTimeMillis(),createdAt=old?.createdAt?:System.currentTimeMillis()))}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}


@Composable fun FamilyMemberList(members:List<FamilyMemberEntity>,open:(FamilyMemberEntity)->Unit,delete:(FamilyMemberEntity)->Unit){
if(members.isEmpty()){Hint("এখনো পরিবারের সদস্য যোগ করা হয়নি। সদস্য যোগ করে তার আলাদা হিসাব শুরু করুন।");return}
LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(members,key={it.id}){m->Card(Modifier.fillMaxWidth().clickable{open(m)},colors=CardDefaults.cardColors(containerColor=panel)){Row(Modifier.padding(16.dp).fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(m.name,color=soft,fontWeight=FontWeight.Bold);Text(m.relation,color=teal,fontSize=12.sp)};Text("বিস্তারিত →",color=gold)} }}}
}
@Composable fun FamilyMemberForm(close:()->Unit,save:(String,String)->Unit){
var name by remember{mutableStateOf("")};var relation by remember{mutableStateOf("Custom")};val roles=listOf("মা","বাবা","ভাই","বোন","স্ত্রী","ছেলে","মেয়ে","Custom")
AlertDialog(onDismissRequest=close,title={Text("পরিবারের সদস্য যোগ করুন")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text("সদস্যের নাম")});roles.chunked(2).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){row.forEach{r->FilterChip(selected=relation==r,onClick={relation=r},label={Text(r)})}}}}},confirmButton={TextButton(onClick={if(name.isNotBlank())save(name,relation)}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}
@Composable fun FamilyTotals(s:FamilyMemberSummary){Card(Modifier.fillMaxWidth().padding(vertical=10.dp),colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("আজীবন মোট",color=soft);Text(money(s.lifetimePoisha),color=gold,fontSize=25.sp,fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("এই মাস",color=soft.copy(alpha=.7f));Text(money(s.monthlyPoisha),color=teal)};Column{Text("এই বছর",color=soft.copy(alpha=.7f));Text(money(s.yearlyPoisha),color=teal)}}}}
}
@Composable fun FamilyEntryList(entries:List<FamilyEntryEntity>,delete:(FamilyEntryEntity)->Unit){
Text("হিসাবের ইতিহাস",color=soft,fontSize=18.sp)
if(entries.isEmpty()){Hint("এই সদস্যের কোনো হিসাব নেই। + চাপ দিয়ে যোগ বা খরচের হিসাব লিখুন।");return}
LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){items(entries,key={it.id}){e->Card(colors=CardDefaults.cardColors(containerColor=panel)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(e.title,color=soft,fontWeight=FontWeight.Bold);if(e.note.isNotBlank())Text(e.note,color=soft.copy(alpha=.7f),fontSize=12.sp)};Text((if(e.type=="ADD")"+" else "−")+money(e.amountPoisha),color=if(e.type=="ADD")teal else gold);TextButton(onClick={delete(e)}){Text("মুছুন")}}}}}
}
@Composable fun FamilyEntryForm(member:FamilyMemberEntity,close:()->Unit,save:(FamilyEntryEntity)->Unit){
var type by remember{mutableStateOf("ADD")};var amount by remember{mutableStateOf("")};var title by remember{mutableStateOf("")};var note by remember{mutableStateOf("")}
AlertDialog(onDismissRequest=close,title={Text("${member.name} • নতুন হিসাব")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Row{FilterChip(type=="ADD",{type="ADD"},label={Text("যোগ")});Spacer(Modifier.width(8.dp));FilterChip(type=="SUBTRACT",{type="SUBTRACT"},label={Text("খরচ / বাদ")})};OutlinedTextField(amount,{amount=it},label={Text("পরিমাণ (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal));OutlinedTextField(title,{title=it},label={Text("বিবরণ")});OutlinedTextField(note,{note=it},label={Text("নোট (ঐচ্ছিক)")})}},confirmButton={TextButton(onClick={parsePoisha(amount)?.let{if(title.isNotBlank())save(FamilyEntryEntity(memberId=member.id,type=type,amountPoisha=it,title=title.trim(),note=note))}}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}
