package com.habib.wealth
import android.os.Bundle
import android.graphics.Paint as AndroidPaint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.habib.wealth.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.Date
import java.util.Calendar
import java.text.SimpleDateFormat
private val navy=Color(0xFF0B1424); private val panel=Color(0xFF152238); private val gold=Color(0xFFE3B85C); private val teal=Color(0xFF48C6B7); private val soft=Color(0xFFEAF0F7)
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{WealthApp(WealthRepository(WealthDatabase.get(this)))}}}
class WealthVM(private val repo:WealthRepository):ViewModel(){
val accounts=repo.accounts.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val txs=repo.transactions.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val notes=repo.expenseNotes.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val family=repo.familyMembers.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
val balances=repo.balances.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
var message by mutableStateOf<String?>(null)
fun run(block:suspend()->Unit){viewModelScope.launch{try{block();message="সংরক্ষণ সম্পন্ন হয়েছে"}catch(e:Exception){message=e.message?:"সমস্যা হয়েছে"}}}
companion object{fun factory(r:WealthRepository)=viewModelFactory{initializer{WealthVM(r)}}}
}
@Composable fun WealthApp(repo:WealthRepository){
    val vm: WealthVM = viewModel(factory = WealthVM.factory(repo))
    val accounts by vm.accounts.collectAsState(); val txs by vm.txs.collectAsState()
    val notes by vm.notes.collectAsState(); val family by vm.family.collectAsState(); val balances by vm.balances.collectAsState()
    var selectedFamily by remember { mutableStateOf<FamilyMemberEntity?>(null) }
    val familyEntriesFlow = remember(selectedFamily?.id) { selectedFamily?.let { repo.familyEntries(it.id) } }
    val familyEntries by (familyEntriesFlow ?: kotlinx.coroutines.flow.flowOf(emptyList())).collectAsState(initial = emptyList())
    var tab by remember { mutableIntStateOf(0) }; var accountDialog by remember { mutableStateOf(false) }
    var txDialog by remember { mutableStateOf(false) }; var edit by remember { mutableStateOf<TransactionEntity?>(null) }
    var noteDialog by remember { mutableStateOf(false) }; var noteEdit by remember { mutableStateOf<ExpenseNoteEntity?>(null) }
    var familyAdd by remember { mutableStateOf(false) }; var familyEntryDialog by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val total=balances.sumOf{it.balancePoisha}; val income=txs.filter{it.type=="INCOME"}.sumOf{it.amountPoisha}; val expense=txs.filter{it.type=="EXPENSE"}.sumOf{it.amountPoisha}
    val context = LocalContext.current
    var showPdfOptions by remember { mutableStateOf(false) }
    var exportScope by remember { mutableStateOf("ALL") }
    val pageTitle = when(tab){0->"Dashboard";1->"Accounts";2->"Transactions";3->"Family Ledger";4->"Expense Notes";else->"More"}
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if(uri!=null) try {
            val lines = buildList {
                add("HABIB WEALTH")
                add(pageTitle)
                add("Generated: "+SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date()))
                add("")
                when(tab){
                    0->{add("Total balance: ${money(total)}");add("Income: ${money(income)}");add("Expense: ${money(expense)}");add("");add("Recent transactions");txs.take(30).forEach{add("${it.title} | ${it.type} | ${money(it.amountPoisha)}")}}
                    1->{add("Accounts");balances.forEach{add("${it.name} (${it.type}) | ${money(it.balancePoisha)}")}}
                    2->{
                        val now=Calendar.getInstance()
                        val selected=txs.filter { t ->
                            val c=Calendar.getInstance().apply{timeInMillis=t.transactionDate}
                            when(exportScope){
                                "MONTH" -> c.get(Calendar.YEAR)==now.get(Calendar.YEAR) && c.get(Calendar.MONTH)==now.get(Calendar.MONTH)
                                "YEAR" -> c.get(Calendar.YEAR)==now.get(Calendar.YEAR)
                                else -> true
                            }
                        }.sortedByDescending{it.transactionDate}
                        add(when(exportScope){"MONTH"->"Transactions - Current Month";"YEAR"->"Transactions - Current Year";else->"Complete Transaction History"})
                        add("Income and expense totals exclude transfers")
                        selected.forEach{t->add("${SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(t.transactionDate))} | ${t.title} | ${t.type} | ${money(t.amountPoisha)}")}
                        add("")
                        add("Income: ${money(selected.filter{it.type=="INCOME"}.sumOf{it.amountPoisha})}")
                        add("Expense: ${money(selected.filter{it.type=="EXPENSE"}.sumOf{it.amountPoisha})}")
                        add("Transfers: ${money(selected.filter{it.type=="TRANSFER"}.sumOf{it.amountPoisha})}")
                    }
                    3->{if(selectedFamily==null){family.forEach{m->add("${m.name} | ${m.relation}")}}else{add("Member: ${selectedFamily!!.name}");add("Lifetime: ${money(repo.familySummary(selectedFamily!!,familyEntries).lifetimePoisha)}");add("This month: ${money(repo.familySummary(selectedFamily!!,familyEntries).monthlyPoisha)}");add("This year: ${money(repo.familySummary(selectedFamily!!,familyEntries).yearlyPoisha)}");familyEntries.forEach{add("${it.title} | ${it.type} | ${money(it.amountPoisha)}")}}}
                    4->{notes.forEach{add("${it.title} | ${money(it.amountPoisha)} | ${it.note}")}}
                    else->{add("HABIB WEALTH menu");add("Accounts, Family Ledger, Expense Notes and Settings")}
                }
                add("");add("Currency: Bangladeshi Taka (BDT)")
            }
            writeTextPdf(context,uri,lines)
            vm.message="PDF সফলভাবে তৈরি হয়েছে"
        } catch(e:Exception){vm.message="PDF তৈরি করা যায়নি: ${e.message}"}
    }
    if(showPdfOptions) AlertDialog(
        onDismissRequest={showPdfOptions=false},
        title={Text("লেনদেনের PDF Export")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("কোন সময়ের হিসাব PDF করবেন?")
            listOf("MONTH" to "শুধু চলতি মাস", "YEAR" to "শুধু চলতি বছর", "ALL" to "সম্পূর্ণ লেনদেন").forEach{(value,label)->
                Row(Modifier.fillMaxWidth().clickable{exportScope=value},verticalAlignment=Alignment.CenterVertically){RadioButton(selected=exportScope==value,onClick={exportScope=value});Text(label)}
            }
        }},
        confirmButton={TextButton(onClick={showPdfOptions=false;pdfLauncher.launch("Habib_Wealth_Transactions_${exportScope}.pdf")}){Text("PDF তৈরি করুন")}},
        dismissButton={TextButton(onClick={showPdfOptions=false}){Text("বাতিল")}}
    )
    MaterialTheme(colorScheme=darkColorScheme(primary=gold,secondary=teal,background=navy,surface=panel,onBackground=soft,onSurface=soft)) {
        Scaffold(containerColor=navy,
            bottomBar={ NavigationBar(containerColor=panel,contentColor=soft){
                val nav=listOf(Triple("হোম",Icons.Default.Home,0),Triple("অ্যাকাউন্ট",Icons.Default.AccountBalanceWallet,1),Triple("লেনদেন",Icons.Default.ReceiptLong,2),Triple("Family",Icons.Default.Groups,3),Triple("More",Icons.Default.GridView,5))
                nav.forEach{(label,ic,index)->NavigationBarItem(selected=tab==index,onClick={tab=index;selectedFamily=null},icon={Icon(ic,null)},label={Text(label,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=gold,selectedTextColor=gold,indicatorColor=navy,unselectedIconColor=soft.copy(alpha=.65f),unselectedTextColor=soft.copy(alpha=.65f)))}
            }},
            floatingActionButton={ if(tab in listOf(1,2,3,4)) FloatingActionButton(onClick={when(tab){1->accountDialog=true;2->{edit=null;txDialog=true};3->if(selectedFamily==null)familyAdd=true else familyEntryDialog=true;4->{noteEdit=null;noteDialog=true}}},containerColor=gold,contentColor=navy){Icon(Icons.Default.Add,"যোগ করুন")} }
        ){pad->
            Column(Modifier.fillMaxSize().padding(pad)) {
                Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=14.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){Text("HABIB WEALTH",color=gold,fontSize=21.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=1.sp);Text("আপনার অর্থ, আপনার নিয়ন্ত্রণে",color=soft.copy(alpha=.65f),fontSize=11.sp)}
                    IconButton(onClick={if(tab==2) showPdfOptions=true else pdfLauncher.launch("Habib_Wealth_${pageTitle.replace(" ","_")}.pdf")}) { Icon(Icons.Default.PictureAsPdf,contentDescription="Export this page as PDF",tint=gold) }
                    Surface(shape=RoundedCornerShape(14.dp),color=teal.copy(alpha=.13f)){Text("HW",Modifier.padding(horizontal=13.dp,vertical=9.dp),color=teal,fontWeight=FontWeight.Bold)}
                }
                when(tab){
                    0->{
                        LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(start=16.dp,end=16.dp,bottom=20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
                            item { Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF173B45)),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)){Text("মোট অ্যাকাউন্ট ব্যালেন্স",color=soft.copy(alpha=.8f),fontSize=13.sp);Spacer(Modifier.height(8.dp));Text(money(total),color=Color.White,fontSize=31.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Text("সব অ্যাকাউন্ট মিলিয়ে",color=teal,fontSize=12.sp)} } }
                            item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){SummaryCard("মোট আয়",money(income),Icons.Default.TrendingUp,teal,Modifier.weight(1f));SummaryCard("মোট খরচ",money(expense),Icons.Default.TrendingDown,gold,Modifier.weight(1f))} }
                            item { Row(verticalAlignment=Alignment.CenterVertically){Text("দ্রুত কাজ",color=soft,fontSize=17.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("Quick Actions",color=soft.copy(alpha=.5f),fontSize=11.sp)} }
                            item { Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){QuickAction("আয় যোগ",Icons.Default.TrendingUp,teal,Modifier.weight(1f)){edit=null;txDialog=true};QuickAction("খরচ যোগ",Icons.Default.TrendingDown,gold,Modifier.weight(1f)){edit=null;txDialog=true};QuickAction("ট্রান্সফার",Icons.Default.SwapHoriz,soft,Modifier.weight(1f)){edit=null;txDialog=true}} }
                            item { Row(verticalAlignment=Alignment.CenterVertically){Text("সাম্প্রতিক লেনদেন",color=soft,fontSize=17.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));TextButton(onClick={tab=2}){Text("সব দেখুন",color=teal)}} }
                            item { TxList(txs.take(5),accounts,{edit=it;txDialog=true},{vm.run{repo.deleteTransaction(it)}}) }
                            item { Text("অ্যাকাউন্ট সারাংশ",color=soft,fontSize=17.sp,fontWeight=FontWeight.Bold) }
                            items(balances.take(3),key={"dash${it.id}"}){b->AccountSummaryRow(b.name,b.type,b.balancePoisha)}
                        }
                    }
                    1->{Column(Modifier.fillMaxSize().padding(horizontal=16.dp)){SectionHeading("আমার অ্যাকাউন্ট","Cash, Bank ও Mobile Wallet");if(balances.isEmpty())Hint("এখনো অ্যাকাউন্ট নেই। + চাপ দিয়ে Cash, Bank বা bKash যোগ করুন।") else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(balances,key={it.id}){b->AccountSummaryRow(b.name,b.type,b.balancePoisha)}}}}
                    2->{Column(Modifier.fillMaxSize().padding(horizontal=16.dp)){SectionHeading("সব লেনদেন","আয় • খরচ • এক অ্যাকাউন্ট থেকে অন্য অ্যাকাউন্টে স্থানান্তর");TxList(txs,accounts,{edit=it;txDialog=true},{vm.run{repo.deleteTransaction(it)}})}}
                    3->{Column(Modifier.fillMaxSize().padding(horizontal=16.dp)){if(selectedFamily==null){SectionHeading("Family Ledger","প্রতিটি সদস্যের আলাদা আজীবন, মাসিক ও বার্ষিক হিসাব");FamilyMemberList(family,{selectedFamily=it},{vm.run{repo.deleteFamilyMember(it)}})}else{val m=selectedFamily!!;TextButton(onClick={selectedFamily=null}){Text("← পরিবারের তালিকা",color=gold)};Text(m.name,color=soft,fontSize=22.sp,fontWeight=FontWeight.Bold);Text(m.relation,color=teal);FamilyTotals(repo.familySummary(m,familyEntries));FamilyEntryList(familyEntries,{vm.run{repo.deleteFamilyEntry(it)}})}}}
                    4->{Column(Modifier.fillMaxSize().padding(horizontal=16.dp)){SectionHeading("স্বতন্ত্র খরচের নোট","এই নোট মূল লেনদেন ও ব্যালেন্স থেকে আলাদা");ExpenseNoteList(notes,{noteEdit=it;noteDialog=true},{vm.run{repo.deleteExpenseNote(it)}})}}
                    else->{LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(horizontal=16.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{SectionHeading("আরও সুবিধা","আপনার অর্থ ব্যবস্থাপনার সব টুল এক জায়গায়")};item{MoreTile("স্বতন্ত্র খরচের নোট","লেনদেনের বাইরে ব্যক্তিগত নোট",Icons.Default.Notes){tab=4}};item{MoreTile("Settings","অ্যাপের সেটিংস ও পছন্দ",Icons.Default.Settings){showSettings=true}};item{MoreTile("Accounts","আপনার সব অ্যাকাউন্ট",Icons.Default.AccountBalance){tab=1}};item{MoreTile("Family Ledger","পরিবারের আলাদা হিসাব",Icons.Default.Groups){tab=3}};item{Text("পরবর্তী ধাপে যুক্ত হবে",color=gold,fontWeight=FontWeight.Bold,fontSize=14.sp)};item{Text("Loans • Bills • Savings Goals • Budgets • Reports & Export • Google Drive Backup • Profile",color=soft.copy(alpha=.7f),fontSize=13.sp,lineHeight=21.sp)};item{Text("HABIB WEALTH  •  Personal Finance",color=teal,fontSize=12.sp)}}}
                }
            }
        }
        if(accountDialog)AccountForm({accountDialog=false}){n,t,v->vm.run{repo.addAccount(n,t,v)};accountDialog=false}
        if(txDialog)TxForm(accounts,edit,{txDialog=false}){t->vm.run{repo.saveTransaction(t)};txDialog=false}
        if(noteDialog)ExpenseNoteForm(noteEdit,{noteDialog=false}){n->vm.run{repo.saveExpenseNote(n)};noteDialog=false}
        if(familyAdd)FamilyMemberForm({familyAdd=false}){n,r->vm.run{repo.addFamilyMember(n,r)};familyAdd=false}
        if(familyEntryDialog&&selectedFamily!=null)FamilyEntryForm(selectedFamily!!,{familyEntryDialog=false}){e->vm.run{repo.saveFamilyEntry(e)};familyEntryDialog=false}
        if(showSettings)AlertDialog(onDismissRequest={showSettings=false},title={Text("Settings")},text={Text("HABIB WEALTH\nসংস্করণ 0.3.0\nমুদ্রা: বাংলাদেশি টাকা (৳)\n\nপ্রোফাইল, নিরাপত্তা ও ক্লাউড ব্যাকআপ পরবর্তী ধাপে যুক্ত হবে।")},confirmButton={TextButton(onClick={showSettings=false}){Text("ঠিক আছে")}},containerColor=panel)
        vm.message?.let{msg->AlertDialog(onDismissRequest={vm.message=null},confirmButton={TextButton(onClick={vm.message=null}){Text("ঠিক আছে")}},title={Text("HABIB WEALTH")},text={Text(msg)},containerColor=panel)}
    }
}
@Composable private fun SectionHeading(title:String,subtitle:String){Column(Modifier.padding(top=4.dp,bottom=14.dp)){Text(title,color=soft,fontSize=21.sp,fontWeight=FontWeight.Bold);Text(subtitle,color=soft.copy(alpha=.58f),fontSize=12.sp,lineHeight=18.sp)}}
@Composable private fun SummaryCard(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,tint:Color,modifier:Modifier=Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp)){Icon(icon,null,tint=tint);Spacer(Modifier.height(8.dp));Text(title,color=soft.copy(alpha=.7f),fontSize=12.sp);Text(value,color=soft,fontSize=17.sp,fontWeight=FontWeight.Bold,maxLines=1)}}}
@Composable private fun QuickAction(title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,tint:Color,modifier:Modifier=Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.fillMaxWidth().padding(vertical=14.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=tint);Spacer(Modifier.height(6.dp));Text(title,color=soft,fontSize=11.sp)}}}
@Composable private fun AccountSummaryRow(name:String,type:String,balance:Long){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(16.dp).fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(12.dp),color=teal.copy(alpha=.13f)){Icon(Icons.Default.AccountBalanceWallet,null,Modifier.padding(10.dp),tint=teal)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(name,color=soft,fontWeight=FontWeight.SemiBold);Text(type,color=soft.copy(alpha=.55f),fontSize=11.sp)};Text(money(balance),color=gold,fontWeight=FontWeight.Bold)}}}
@Composable private fun MoreTile(title:String,subtitle:String,icon:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable(onClick=onClick),colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(12.dp),color=teal.copy(alpha=.12f)){Icon(icon,null,Modifier.padding(10.dp),tint=teal)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,color=soft,fontWeight=FontWeight.SemiBold);Text(subtitle,color=soft.copy(alpha=.55f),fontSize=11.sp)};Icon(Icons.Default.ArrowForward,null,tint=gold)}}}
@Composable fun Hint(s:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=panel)){Text(s,Modifier.padding(16.dp),color=soft)}}
@Composable fun AccountForm(close:()->Unit,save:(String,String,Long)->Unit){
var n by remember{mutableStateOf("")};var type by remember{mutableStateOf("Cash")};var opening by remember{mutableStateOf("0")}
AlertDialog(onDismissRequest=close,title={Text("নতুন অ্যাকাউন্ট")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(n,{n=it},label={Text("অ্যাকাউন্টের নাম")});Row{listOf("Cash","Bank","bKash").forEach{FilterChip(type==it,{type=it},label={Text(it)})}};OutlinedTextField(opening,{opening=it},label={Text("প্রারম্ভিক ব্যালেন্স (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))}},confirmButton={TextButton(onClick={parsePoisha(opening)?.let{save(n,type,it)}}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}
@Composable fun TxForm(accounts:List<AccountEntity>,old:TransactionEntity?,close:()->Unit,save:(TransactionEntity)->Unit){
var type by remember{mutableStateOf(old?.type?:"EXPENSE")};var amount by remember{mutableStateOf(old?.let{decimal(it.amountPoisha)}?:"")};var aid by remember{mutableLongStateOf(old?.accountId?:accounts.firstOrNull()?.id?:0L)};var dest by remember{mutableLongStateOf(old?.destinationAccountId?:accounts.firstOrNull{it.id!=aid}?.id?:0L)};var title by remember{mutableStateOf(old?.title?:"")};var note by remember{mutableStateOf(old?.note?:"")};var receiptUri by remember{mutableStateOf(old?.receiptUri)}
val context = LocalContext.current
val receiptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
    if(uri!=null){ try{context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}; receiptUri=uri.toString() }
}
AlertDialog(onDismissRequest=close,title={Text(if(old==null)"নতুন লেনদেন" else "লেনদেন সম্পাদনা")},text={Column(Modifier.heightIn(max=470.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
Row{listOf("INCOME" to "আয়","EXPENSE" to "খরচ","TRANSFER" to "ট্রান্সফার").forEach{(v,l)->FilterChip(type==v,{type=v},label={Text(l)})}}
OutlinedTextField(amount,{amount=it},label={Text("পরিমাণ (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
Text("অ্যাকাউন্ট");accounts.forEach{a->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(aid==a.id,{aid=a.id});Text(a.name)}}
if(type=="TRANSFER"){Text("গন্তব্য অ্যাকাউন্ট");accounts.filter{it.id!=aid}.forEach{a->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(dest==a.id,{dest=a.id});Text(a.name)}}}
OutlinedTextField(title,{title=it},label={Text("কারণ / শিরোনাম")});OutlinedTextField(note,{note=it},label={Text("বিস্তারিত (ঐচ্ছিক)")})
Row(verticalAlignment=Alignment.CenterVertically){TextButton(onClick={receiptPicker.launch(arrayOf("image/*"))}){Text(if(receiptUri==null)"গ্যালারি থেকে রসিদ / ছবি যুক্ত করুন" else "ছবি পরিবর্তন করুন")};if(receiptUri!=null)Text("ছবি যুক্ত",color=teal,fontSize=11.sp)}
}},confirmButton={TextButton(onClick={val p=parsePoisha(amount);if(p!=null&&aid!=0L)save(TransactionEntity(id=old?.id?:0,type=type,amountPoisha=p,accountId=aid,destinationAccountId=if(type=="TRANSFER")dest else null,title=title.ifBlank{"লেনদেন"},note=note,receiptUri=receiptUri,transactionDate=old?.transactionDate?:System.currentTimeMillis(),createdAt=old?.createdAt?:System.currentTimeMillis()))}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}
@Composable fun TxList(txs:List<TransactionEntity>,accounts:List<AccountEntity>,edit:(TransactionEntity)->Unit,delete:(TransactionEntity)->Unit){
    if(txs.isEmpty()){Hint("এখনো কোনো লেনদেন নেই। + চাপ দিয়ে প্রথম লেনদেন যোগ করুন।");return}
    val locale=Locale("bn","BD")
    val yearFmt=remember{SimpleDateFormat("yyyy",Locale.US)}
    val monthFmt=remember{SimpleDateFormat("MMMM",locale)}
    val monthKeyFmt=remember{SimpleDateFormat("yyyy-MM",Locale.US)}
    val grouped=remember(txs){txs.sortedByDescending{it.transactionDate}.groupBy{yearFmt.format(Date(it.transactionDate))}.mapValues{(_,yearItems)->yearItems.groupBy{monthKeyFmt.format(Date(it.transactionDate))}.toSortedMap(compareByDescending{it})}}
    val openYears= remember { mutableStateMapOf<String,Boolean>() }
    val openMonths= remember { mutableStateMapOf<String,Boolean>() }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)) {
        grouped.forEach{(year,months)->
            item(key="year-$year") {
                Card(Modifier.fillMaxWidth().clickable{openYears[year]=!(openYears[year]?:true)},colors=CardDefaults.cardColors(containerColor=Color(0xFF20334D)),shape=RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(15.dp).fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("📁",fontSize=20.sp);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(year,color=gold,fontSize=18.sp,fontWeight=FontWeight.Bold);Text("${months.values.sumOf{it.size}} টি লেনদেন",color=soft.copy(alpha=.65f),fontSize=11.sp)};Text(if(openYears[year]?:true)"⌄" else "›",color=gold,fontSize=22.sp)}
                }
            }
            if(openYears[year]?:true) months.forEach{(monthKey,itemsInMonth)->
                item(key="month-$monthKey") {
                    Card(Modifier.fillMaxWidth().padding(start=12.dp).clickable{openMonths[monthKey]=!(openMonths[monthKey]?:true)},colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(14.dp)) {
                        Row(Modifier.padding(13.dp).fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("📂",fontSize=18.sp);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(monthFmt.format(Date(itemsInMonth.first().transactionDate))+" $year",color=soft,fontWeight=FontWeight.SemiBold);Text("${itemsInMonth.size} টি • ${money(itemsInMonth.sumOf{if(it.type=="EXPENSE")it.amountPoisha else 0L})} খরচ",color=soft.copy(alpha=.6f),fontSize=11.sp)};Text(if(openMonths[monthKey]?:true)"⌄" else "›",color=teal,fontSize=20.sp)}
                    }
                }
                if(openMonths[monthKey]?:true) itemsInMonth.forEach{t->
                    item(key="tx-${t.id}") {
                        val from=accounts.firstOrNull{it.id==t.accountId}?.name?:"";val to=accounts.firstOrNull{it.id==t.destinationAccountId}?.name?:""
                        Card(Modifier.padding(start=25.dp).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=panel.copy(alpha=.82f)),shape=RoundedCornerShape(13.dp)) {Column(Modifier.padding(12.dp).fillMaxWidth()){
                            Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.title,color=soft,fontWeight=FontWeight.Bold);Text(when(t.type){"INCOME"->"আয় • $from";"EXPENSE"->"খরচ • $from";else->"ট্রান্সফার • $from → $to"},color=teal,fontSize=12.sp)};Text((if(t.type=="INCOME")"+" else if(t.type=="EXPENSE")"−" else "")+money(t.amountPoisha),color=gold)}
                            if(t.note.isNotBlank())Text(t.note,color=soft.copy(alpha=.7f),fontSize=12.sp)
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){TextButton(onClick={edit(t)}){Icon(Icons.Default.Edit,null);Text("এডিট")};TextButton(onClick={delete(t)}){Icon(Icons.Default.Delete,null);Text("মুছুন")}}
                        }}
                    }
                }
            }
        }
    }
}
fun parsePoisha(s:String):Long?=try{val p=s.trim().replace(",","").split(".");if(p[0].isBlank())null else p[0].toLong()*100+(p.getOrNull(1)?:"").padEnd(2,'0').take(2).toLong()}catch(_:Exception){null}
fun money(p:Long)="৳"+String.format(Locale.US,"%,.2f",p/100.0)
fun decimal(p:Long)=String.format(Locale.US,"%.2f",p/100.0)

@Composable fun ExpenseNoteList(notes:List<ExpenseNoteEntity>,edit:(ExpenseNoteEntity)->Unit,delete:(ExpenseNoteEntity)->Unit){
if(notes.isEmpty()){Hint("এখনো কোনো খরচের নোট নেই। + চাপ দিয়ে আলাদা নোট যোগ করুন।");return}
LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(notes,key={it.id}){n->Card(colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(12.dp).fillMaxWidth()){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(n.title,color=soft,fontWeight=FontWeight.Bold);if(n.note.isNotBlank())Text(n.note,color=soft.copy(alpha=.75f))};Text(money(n.amountPoisha),color=gold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){TextButton(onClick={edit(n)}){Icon(Icons.Default.Edit,null);Text("এডিট")};TextButton(onClick={delete(n)}){Icon(Icons.Default.Delete,null);Text("মুছুন")}}}}}}
}
@Composable fun ExpenseNoteForm(old:ExpenseNoteEntity?,close:()->Unit,save:(ExpenseNoteEntity)->Unit){
var title by remember(old?.id){mutableStateOf(old?.title?:"")};var amount by remember(old?.id){mutableStateOf(old?.let{decimal(it.amountPoisha)}?:"")};var note by remember(old?.id){mutableStateOf(old?.note?:"")}
AlertDialog(onDismissRequest=close,title={Text(if(old==null)"নতুন খরচের নোট" else "নোট সম্পাদনা")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("শিরোনাম")});OutlinedTextField(amount,{amount=it},label={Text("পরিমাণ (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal));OutlinedTextField(note,{note=it},label={Text("বিস্তারিত (ঐচ্ছিক)")})}},confirmButton={TextButton(onClick={val p=parsePoisha(amount);if(p!=null&&title.isNotBlank())save(ExpenseNoteEntity(id=old?.id?:0,title=title.trim(),amountPoisha=p,note=note,noteDate=old?.noteDate?:System.currentTimeMillis(),createdAt=old?.createdAt?:System.currentTimeMillis()))}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}


@Composable fun FamilyMemberList(members:List<FamilyMemberEntity>,open:(FamilyMemberEntity)->Unit,delete:(FamilyMemberEntity)->Unit){
if(members.isEmpty()){Hint("এখনো পরিবারের সদস্য যোগ করা হয়নি। সদস্য যোগ করে তার আলাদা হিসাব শুরু করুন।");return}
LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(members,key={it.id}){m->Card(Modifier.fillMaxWidth().clickable{open(m)},colors=CardDefaults.cardColors(containerColor=panel)){Row(Modifier.padding(16.dp).fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(m.name,color=soft,fontWeight=FontWeight.Bold);Text(m.relation,color=teal,fontSize=12.sp)};Text("বিস্তারিত →",color=gold)} }}}
}
@Composable fun FamilyMemberForm(close:()->Unit,save:(String,String)->Unit){
var name by remember{mutableStateOf("")};var relation by remember{mutableStateOf("Custom")};val roles=listOf("মা","বাবা","ভাই","বোন","স্ত্রী","ছেলে","মেয়ে","Custom")
AlertDialog(onDismissRequest=close,title={Text("পরিবারের সদস্য যোগ করুন")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text("সদস্যের নাম")});roles.chunked(2).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){row.forEach{r->FilterChip(selected=relation==r,onClick={relation=r},label={Text(r)})}}}}},confirmButton={TextButton(onClick={if(name.isNotBlank())save(name,relation)}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}
@Composable fun FamilyTotals(s:FamilyMemberSummary){Card(Modifier.fillMaxWidth().padding(vertical=10.dp),colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("আজীবন মোট",color=soft);Text(money(s.lifetimePoisha),color=gold,fontSize=25.sp,fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("এই মাস",color=soft.copy(alpha=.7f));Text(money(s.monthlyPoisha),color=teal)};Column{Text("এই বছর",color=soft.copy(alpha=.7f));Text(money(s.yearlyPoisha),color=teal)}}}}
}
@Composable fun FamilyEntryList(entries:List<FamilyEntryEntity>,delete:(FamilyEntryEntity)->Unit){
Text("হিসাবের ইতিহাস",color=soft,fontSize=18.sp)
if(entries.isEmpty()){Hint("এই সদস্যের কোনো হিসাব নেই। + চাপ দিয়ে যোগ বা খরচের হিসাব লিখুন।");return}
LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){items(entries,key={it.id}){e->Card(colors=CardDefaults.cardColors(containerColor=panel)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(e.title,color=soft,fontWeight=FontWeight.Bold);if(e.note.isNotBlank())Text(e.note,color=soft.copy(alpha=.7f),fontSize=12.sp)};Text((if(e.type=="ADD")"+" else "−")+money(e.amountPoisha),color=if(e.type=="ADD")teal else gold);TextButton(onClick={delete(e)}){Text("মুছুন")}}}}}
}
@Composable fun FamilyEntryForm(member:FamilyMemberEntity,close:()->Unit,save:(FamilyEntryEntity)->Unit){
var type by remember{mutableStateOf("ADD")};var amount by remember{mutableStateOf("")};var title by remember{mutableStateOf("")};var note by remember{mutableStateOf("")}
AlertDialog(onDismissRequest=close,title={Text("${member.name} • নতুন হিসাব")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Row{FilterChip(type=="ADD",{type="ADD"},label={Text("যোগ")});Spacer(Modifier.width(8.dp));FilterChip(type=="SUBTRACT",{type="SUBTRACT"},label={Text("খরচ / বাদ")})};OutlinedTextField(amount,{amount=it},label={Text("পরিমাণ (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal));OutlinedTextField(title,{title=it},label={Text("বিবরণ")});OutlinedTextField(note,{note=it},label={Text("নোট (ঐচ্ছিক)")})}},confirmButton={TextButton(onClick={parsePoisha(amount)?.let{if(title.isNotBlank())save(FamilyEntryEntity(memberId=member.id,type=type,amountPoisha=it,title=title.trim(),note=note))}}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})
}


private fun writeTextPdf(context: android.content.Context, uri: Uri, lines: List<String>) {
    val resolver = context.contentResolver
    val document = PdfDocument()
    val bengaliTypeface = android.graphics.Typeface.createFromAsset(context.assets, "NotoSansBengali.ttf")
    val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(25, 38, 58)
        textSize = 11f
        typeface = bengaliTypeface
    }
    val titlePaint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(15, 105, 96)
        textSize = 20f
        typeface = android.graphics.Typeface.create(bengaliTypeface, android.graphics.Typeface.BOLD)
    }
    val headerPaint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(15, 105, 96)
        textSize = 10f
        typeface = android.graphics.Typeface.create(bengaliTypeface, android.graphics.Typeface.BOLD)
    }
    val footerPaint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(100, 110, 125)
        textSize = 9f
        typeface = bengaliTypeface
    }
    val pageWidth = 595
    val pageHeight = 842
    val margin = 42f
    val lineHeight = 18f
    val maxWidth = pageWidth - margin * 2
    val reportTitle = (lines.firstOrNull() ?: "HABIB WEALTH").take(34)
    var pageNumber = 1
    var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
    var canvas = page.canvas
    var y = 58f

    fun finishCurrentPage() {
        canvas.drawText("Page $pageNumber", pageWidth - margin - 42f, pageHeight - 24f, footerPaint)
        document.finishPage(page)
    }

    fun startNextPage() {
        finishCurrentPage()
        pageNumber++
        page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        canvas = page.canvas
        canvas.drawText("$reportTitle  |  CONTINUED", margin, 34f, headerPaint)
        canvas.drawLine(margin, 44f, pageWidth - margin, 44f, footerPaint)
        y = 68f
    }

    canvas.drawText(lines.firstOrNull() ?: "HABIB WEALTH", margin, y, titlePaint)
    y += 34f

    lines.drop(1).forEach { line ->
        val safe = line.replace("৳", "BDT ").replace("•", "-")
        val words = safe.split(" ")
        var current = ""

        fun drawPdfLine(text: String) {
            if (y > pageHeight - 48f) startNextPage()
            canvas.drawText(text, margin, y, paint)
            y += lineHeight
        }

        words.forEach { word ->
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (paint.measureText(candidate) <= maxWidth) {
                current = candidate
            } else {
                if (current.isNotEmpty()) {
                    drawPdfLine(current)
                    current = ""
                }
                // Also wrap unusually long unbroken words so they cannot run off the A4 page.
                var fragment = ""
                word.forEach { character ->
                    val next = fragment + character
                    if (paint.measureText(next) > maxWidth && fragment.isNotEmpty()) {
                        drawPdfLine(fragment)
                        fragment = character.toString()
                    } else {
                        fragment = next
                    }
                }
                current = fragment
            }
        }
        if (current.isNotEmpty()) drawPdfLine(current)
    }

    finishCurrentPage()
    try {
        resolver.openOutputStream(uri)?.use { document.writeTo(it) }
            ?: throw IllegalStateException("ফাইল সংরক্ষণের স্থান খোলা যায়নি")
    } finally {
        document.close()
    }
}
