package com.habib.wealth.data
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
@Entity(tableName="accounts")
data class AccountEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val type:String,val openingBalancePoisha:Long=0,val createdAt:Long=System.currentTimeMillis())
@Entity(tableName="transactions")
data class TransactionEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val type:String,val amountPoisha:Long,val accountId:Long,val destinationAccountId:Long?=null,val title:String,val note:String="",val receiptUri:String?=null,val transactionDate:Long=System.currentTimeMillis(),val createdAt:Long=System.currentTimeMillis())
data class AccountBalance(val id:Long,val name:String,val type:String,val balancePoisha:Long)

@Entity(tableName="expense_notes")
data class ExpenseNoteEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val title:String,val amountPoisha:Long,val note:String="",val noteDate:Long=System.currentTimeMillis(),val createdAt:Long=System.currentTimeMillis())


@Entity(tableName="family_members")
data class FamilyMemberEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val relation:String,val photoUri:String?=null,val createdAt:Long=System.currentTimeMillis())

@Entity(tableName="family_entries", indices=[Index("memberId"),Index("entryDate")])
data class FamilyEntryEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val memberId:Long,val type:String,val amountPoisha:Long,val title:String,val note:String="",val entryDate:Long=System.currentTimeMillis(),val createdAt:Long=System.currentTimeMillis())

data class FamilyMemberSummary(val memberId:Long,val name:String,val relation:String,val lifetimePoisha:Long,val monthlyPoisha:Long,val yearlyPoisha:Long)
