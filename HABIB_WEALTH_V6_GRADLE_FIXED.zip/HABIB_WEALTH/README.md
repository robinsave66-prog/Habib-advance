# HABIB WEALTH

Android personal finance app for Bangladesh (BDT / poisha).

Current functional milestones:
- Room-backed accounts, income, expenses, transfers and transaction history.
- Independent Expense Notes that do not affect account balances or transactions.
- Family Ledger with members, separate add/subtract entries, and lifetime/monthly/yearly summaries.

Family Ledger is isolated from personal accounts and transactions. 100 poisha = ৳1. This is an in-progress product, not the complete planned application.
