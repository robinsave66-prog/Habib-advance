# HABIB WEALTH
Bengali-first personal and family finance Android app.
- Application ID: `com.habib.wealth`
- Currency: BDT (৳); money stored as integer poisha.
- Kotlin, Jetpack Compose, Room, offline-first foundation.

## Build
A GitHub Actions workflow is included at `.github/workflows/android.yml`. Push this project to a GitHub repository and run the workflow from Actions. Download the `Habib_Wealth` artifact.

## Milestone status
This ZIP is the **foundation milestone**, not the finished app. It contains Android configuration, Room account/transaction schema, integer-poisha accounting rules, a basic Bengali dashboard, unit tests, and cloud build workflow. Family, loans/repayments, savings, bills, archive, receipts, PDF/Excel/CSV, backup/restore, PIN/security and their complete screens remain to be implemented in later milestones. No unimplemented feature is claimed as complete.

Fresh install: zero balances. Negative balances are allowed. Transfers and borrowing/loans are not counted as ordinary income/expense.
