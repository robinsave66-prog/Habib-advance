package com.habib.wealth.domain
import org.junit.Assert.assertEquals
import org.junit.Test

class AccountingEngineTest {
 @Test fun freshAccountIsZero() { assertEquals(0L, AccountingEngine.balanceFor(AccountBalance(1, 0), emptyList())) }
 @Test fun incomeAdds() { assertEquals(12550L, AccountingEngine.balanceFor(AccountBalance(1, 0), listOf(LedgerEntry(EntryType.INCOME, 12550, 1)))) }
 @Test fun negativeBalanceAllowed() { assertEquals(-25000L, AccountingEngine.balanceFor(AccountBalance(1, 0), listOf(LedgerEntry(EntryType.EXPENSE, 25000, 1)))) }
 @Test fun transferIsNotIncomeOrExpense() {
  val entries = listOf(LedgerEntry(EntryType.TRANSFER, 7000, 1, 2))
  assertEquals(-7000L, AccountingEngine.balanceFor(AccountBalance(1, 0), entries))
  assertEquals(7000L, AccountingEngine.balanceFor(AccountBalance(2, 0), entries))
  assertEquals(0L, AccountingEngine.incomeTotal(entries)); assertEquals(0L, AccountingEngine.expenseTotal(entries))
 }
 @Test fun loanIsNotExpense() {
  val entries = listOf(LedgerEntry(EntryType.LOAN_GIVEN, 5000, 1))
  assertEquals(-5000L, AccountingEngine.balanceFor(AccountBalance(1, 0), entries))
  assertEquals(0L, AccountingEngine.expenseTotal(entries))
 }
 @Test fun borrowingIsNotIncome() {
  val entries = listOf(LedgerEntry(EntryType.BORROWED, 9000, 1))
  assertEquals(9000L, AccountingEngine.balanceFor(AccountBalance(1, 0), entries))
  assertEquals(0L, AccountingEngine.incomeTotal(entries))
 }
}
