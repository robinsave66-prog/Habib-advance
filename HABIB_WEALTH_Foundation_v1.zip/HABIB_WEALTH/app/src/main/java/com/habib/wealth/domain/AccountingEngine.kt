package com.habib.wealth.domain

enum class EntryType { INCOME, EXPENSE, TRANSFER, LOAN_GIVEN, BORROWED, SAVING }
data class AccountBalance(val accountId: Long, val openingBalancePoisha: Long)
data class LedgerEntry(val type: EntryType, val amountPoisha: Long, val accountId: Long, val destinationAccountId: Long? = null)

object AccountingEngine {
 fun balanceFor(account: AccountBalance, entries: List<LedgerEntry>): Long =
  entries.fold(account.openingBalancePoisha) { balance, e ->
   require(e.amountPoisha >= 0L) { "Amount must be non-negative" }
   when (e.type) {
    EntryType.INCOME -> if (e.accountId == account.accountId) Math.addExact(balance, e.amountPoisha) else balance
    EntryType.EXPENSE, EntryType.LOAN_GIVEN, EntryType.SAVING -> if (e.accountId == account.accountId) Math.addExact(balance, -e.amountPoisha) else balance
    EntryType.BORROWED -> if (e.accountId == account.accountId) Math.addExact(balance, e.amountPoisha) else balance
    EntryType.TRANSFER -> when (account.accountId) {
     e.accountId -> Math.addExact(balance, -e.amountPoisha)
     e.destinationAccountId -> Math.addExact(balance, e.amountPoisha)
     else -> balance
    }
   }
  }
 fun incomeTotal(entries: List<LedgerEntry>) = entries.filter { it.type == EntryType.INCOME }.sumOf { it.amountPoisha }
 fun expenseTotal(entries: List<LedgerEntry>) = entries.filter { it.type == EntryType.EXPENSE }.sumOf { it.amountPoisha }
}
