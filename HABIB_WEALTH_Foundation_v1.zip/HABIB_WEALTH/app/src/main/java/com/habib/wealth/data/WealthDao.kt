package com.habib.wealth.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface AccountDao {
 @Insert suspend fun insertAccount(account: AccountEntity): Long
 @Query("SELECT * FROM accounts WHERE isArchived = 0 ORDER BY id") fun observeAccounts(): Flow<List<AccountEntity>>
 @Query("SELECT COALESCE(SUM(openingBalancePoisha), 0) FROM accounts WHERE isArchived = 0") fun observeOpeningBalanceTotal(): Flow<Long>
 @Query("SELECT COUNT(*) FROM accounts") suspend fun accountCount(): Int
}
@Dao interface TransactionDao {
 @Insert suspend fun insert(transaction: TransactionEntity): Long
 @Query("SELECT * FROM transactions WHERE isDeleted = 0 ORDER BY transactionDateEpochMillis DESC, id DESC") fun observeTransactions(): Flow<List<TransactionEntity>>
 @Query("UPDATE transactions SET isDeleted = 1 WHERE id = :id") suspend fun softDelete(id: Long)
}
