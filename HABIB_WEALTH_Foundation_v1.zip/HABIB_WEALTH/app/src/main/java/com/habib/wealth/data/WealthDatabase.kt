package com.habib.wealth.data
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AccountEntity::class, TransactionEntity::class], version = 1, exportSchema = true)
abstract class WealthDatabase : RoomDatabase() {
 abstract fun accountDao(): AccountDao
 abstract fun transactionDao(): TransactionDao
 companion object {
  @Volatile private var INSTANCE: WealthDatabase? = null
  fun getInstance(context: Context): WealthDatabase = INSTANCE ?: synchronized(this) {
   INSTANCE ?: Room.databaseBuilder(context.applicationContext, WealthDatabase::class.java, "habib_wealth.db").build().also { INSTANCE = it }
  }
 }
}
