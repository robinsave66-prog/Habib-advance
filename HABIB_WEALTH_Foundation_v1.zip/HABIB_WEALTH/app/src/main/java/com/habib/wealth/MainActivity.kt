package com.habib.wealth

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habib.wealth.data.WealthDatabase
import com.habib.wealth.data.AccountRepository
import com.habib.wealth.ui.theme.WealthTheme

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val repo = AccountRepository(WealthDatabase.getInstance(applicationContext).accountDao())
  setContent { WealthTheme {
   var total by remember { mutableLongStateOf(0L) }
   LaunchedEffect(Unit) { repo.observeTotalBalance().collect { total = it } }
   Scaffold(containerColor = Color(0xFF081525), bottomBar = {
    NavigationBar(containerColor = Color(0xFF10243A)) {
     listOf("হোম", "লেনদেন", "+", "পরিবার", "রিপোর্ট").forEachIndexed { i, label ->
      NavigationBarItem(selected = i == 0, onClick = {}, icon = { Text("•", color = Color(0xFFD9B56D)) }, label = { Text(label, color = Color.White) })
     }
    }
   }) { pad ->
    Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
     Text("HABIB WEALTH", color = Color(0xFFD9B56D), fontSize = 23.sp, fontWeight = FontWeight.Bold)
     Text("আপনার ব্যক্তিগত ও পারিবারিক হিসাব", color = Color.LightGray)
     Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF142B43))) {
      Column(Modifier.fillMaxWidth().padding(20.dp)) {
       Text("মোট ব্যালেন্স", color = Color.LightGray)
       Text("৳${total / 100}.${(kotlin.math.abs(total) % 100).toString().padStart(2, '0')}", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
      }
     }
     Text("নতুন ইনস্টলে ব্যালেন্স ৳০.০০ থেকে শুরু হবে।", color = Color.LightGray)
     Text("এটি প্রাথমিক ভিত্তি সংস্করণ। পরবর্তী ধাপে পূর্ণ লেনদেন, পরিবার, ঋণ, সঞ্চয়, আর্কাইভ ও রিপোর্ট যুক্ত হবে।", color = Color(0xFF9EB0C4))
    }
   }
  } }
 }
}
