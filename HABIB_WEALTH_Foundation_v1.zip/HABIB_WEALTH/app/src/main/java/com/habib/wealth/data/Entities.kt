package com.habib.wealth.data
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts")
data class AccountEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val openingBalancePoisha: Long = 0L, val createdAtEpochMillis: Long = System.currentTimeMillis(), val isArchived: Boolean = false)

@Entity(tableName = "transactions")
data class TransactionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val type: String, val amountPoisha: Long, val accountId: Long, val destinationAccountId: Long? = null, val personId: Long? = null, val purpose: String = "", val description: String = "", val transactionDateEpochMillis: Long, val createdAtEpochMillis: Long = System.currentTimeMillis(), val isDeleted: Boolean = false)
