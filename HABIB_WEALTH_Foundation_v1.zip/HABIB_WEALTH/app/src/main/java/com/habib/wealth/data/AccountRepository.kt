package com.habib.wealth.data
import kotlinx.coroutines.flow.Flow

class AccountRepository(private val dao: AccountDao) {
 fun observeTotalBalance(): Flow<Long> = dao.observeOpeningBalanceTotal()
 suspend fun createDefaultAccountsIfMissing() {
  if (dao.accountCount() == 0) {
   dao.insertAccount(AccountEntity(name = "Cash"))
   dao.insertAccount(AccountEntity(name = "Bank"))
   dao.insertAccount(AccountEntity(name = "bKash"))
  }
 }
}
