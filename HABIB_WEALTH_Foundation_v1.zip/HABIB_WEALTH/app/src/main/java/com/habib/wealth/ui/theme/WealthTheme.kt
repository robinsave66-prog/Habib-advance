package com.habib.wealth.ui.theme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
@Composable fun WealthTheme(content: @Composable () -> Unit) {
 MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFD9B56D), secondary = Color(0xFF3DB7A3), background = Color(0xFF081525), surface = Color(0xFF142B43)), content = content)
}
