package com.habib.wealth.data
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
@Database(entities=[AccountEntity::class,TransactionEntity::class],version=1,exportSchema=false)
abstract class WealthDatabase:RoomDatabase(){
abstract fun dao():WealthDao
companion object {
@Volatile private var INSTANCE:WealthDatabase?=null
fun get(c:Context):WealthDatabase=INSTANCE?: synchronized(this){INSTANCE?:Room.databaseBuilder(c.applicationContext,WealthDatabase::class.java,"habib_wealth.db").build().also{INSTANCE=it}}
}
}
