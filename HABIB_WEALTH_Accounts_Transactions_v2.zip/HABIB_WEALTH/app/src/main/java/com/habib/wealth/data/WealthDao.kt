package com.habib.wealth.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface WealthDao {
@Query("SELECT * FROM accounts ORDER BY id") fun observeAccounts():Flow<List<AccountEntity>>
@Query("SELECT * FROM transactions ORDER BY transactionDate DESC,id DESC") fun observeTransactions():Flow<List<TransactionEntity>>
@Query("SELECT * FROM accounts WHERE id=:id") suspend fun getAccount(id:Long):AccountEntity?
@Query("SELECT COUNT(*) FROM transactions WHERE accountId=:id OR destinationAccountId=:id") suspend fun transactionCountForAccount(id:Long):Int
@Insert suspend fun insertAccount(a:AccountEntity):Long
@Delete suspend fun deleteAccount(a:AccountEntity)
@Insert suspend fun insertTransaction(t:TransactionEntity):Long
@Update suspend fun updateTransaction(t:TransactionEntity)
@Delete suspend fun deleteTransaction(t:TransactionEntity)
}
