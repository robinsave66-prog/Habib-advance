package com.habib.wealth.data
import androidx.room.withTransaction
import kotlinx.coroutines.flow.*
class WealthRepository(private val db:WealthDatabase){
private val dao=db.dao()
val accounts=dao.observeAccounts()
val transactions=dao.observeTransactions()
val balances=combine(accounts,transactions){ aa,tt -> aa.map{a->
var b=a.openingBalancePoisha
tt.forEach{t->when(t.type){"INCOME"->if(t.accountId==a.id)b+=t.amountPoisha;"EXPENSE"->if(t.accountId==a.id)b-=t.amountPoisha;"TRANSFER"->{if(t.accountId==a.id)b-=t.amountPoisha;if(t.destinationAccountId==a.id)b+=t.amountPoisha}}}
AccountBalance(a.id,a.name,a.type,b)
}}
suspend fun addAccount(n:String,t:String,opening:Long){require(n.isNotBlank()){"অ্যাকাউন্টের নাম লিখুন"};require(opening>=0);dao.insertAccount(AccountEntity(name=n.trim(),type=t,openingBalancePoisha=opening))}
suspend fun saveTransaction(t:TransactionEntity){
require(t.amountPoisha>0){"টাকার পরিমাণ শূন্যের বেশি হতে হবে"};require(dao.getAccount(t.accountId)!=null){"অ্যাকাউন্ট পাওয়া যায়নি"}
if(t.type=="TRANSFER"){require(t.destinationAccountId!=null&&t.destinationAccountId!=t.accountId){"ভিন্ন গন্তব্য অ্যাকাউন্ট নির্বাচন করুন"};require(dao.getAccount(t.destinationAccountId)!=null){"গন্তব্য অ্যাকাউন্ট পাওয়া যায়নি"}}
db.withTransaction{if(t.id==0L)dao.insertTransaction(t) else dao.updateTransaction(t)}
}
suspend fun deleteTransaction(t:TransactionEntity)=dao.deleteTransaction(t)
suspend fun deleteAccount(a:AccountEntity){require(dao.transactionCountForAccount(a.id)==0){"এই অ্যাকাউন্টে লেনদেন আছে"};dao.deleteAccount(a)}
}
