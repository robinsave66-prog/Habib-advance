package com.habib.wealth.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName="accounts")
data class AccountEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val type:String,val openingBalancePoisha:Long=0,val createdAt:Long=System.currentTimeMillis())
@Entity(tableName="transactions")
data class TransactionEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val type:String,val amountPoisha:Long,val accountId:Long,val destinationAccountId:Long?=null,val title:String,val note:String="",val transactionDate:Long=System.currentTimeMillis(),val createdAt:Long=System.currentTimeMillis())
data class AccountBalance(val id:Long,val name:String,val type:String,val balancePoisha:Long)
