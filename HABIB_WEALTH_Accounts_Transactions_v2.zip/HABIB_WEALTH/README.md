# HABIB WEALTH — Accounts & Transactions v2

Functional milestone: Room database, accounts, income, expense, transfers, transaction history, edit and delete. This is not the complete product. Money is stored as integer poisha (100 poisha = ৳1).
